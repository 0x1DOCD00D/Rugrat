This program generates simple Java programs with lots of if-else, switch statements.
Parameters:
<Class Name>
<Number of Variables>
<Maximum number of methods>
<Minimum number of LOC>
<Probability - to create nested loop and others>
<Maximum nested 'if' statements>
<Maximum allowed method calls from a single method>