package edu.uta.cse.proggen.nodes;

/**
 * Interface of all expressions
 * @author Ishtiaque_Hussain
 *
 */
public class Expression 
{
	public String toString()
	{
		return null;
	}

}
