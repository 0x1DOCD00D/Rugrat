package edu.uta.cse.proggen.nodes;

/**
 * Superclass of all operators
 * 
 * @author Ishtiaque_Hussain
 *
 */

public class Operator {

	@Override
	public String toString(){
		return "Not extended";
	}


}
