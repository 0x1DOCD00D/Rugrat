public class Test {
private static int i0;
private static int i1;
private static int i2;
private static int i3;
private static int i4;
private static int i5;
private static int i6;
private static int i7;
private static int i8;
private static int i9;
public Test(){
}


//Method
 public static void meth_1( int i0, int i1, int i2, int i3, int i4, int i5, int i6, int i7, int i8, int i9){

switch(i0){
case 0:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 1:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 2:
i0 = ((i1+i6)/(-7));
 break;
case 3:
System.out.println("Hello");
 break;
default :
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

if((i6>i5)){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}
else{
 System.out.println("Hello");
System.out.println("Hello");
}

switch(i5){
case 0:
System.out.println("Hello");
 break;
case 1:
i6 = ((i0/i5)+(-4));
 break;
case 2:
System.out.println("Hello");
 break;
case 3:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
default :
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

if((i1<=i2)){
i5 = (8*(i5-i6));
}
else{
 System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

switch(i7){
case 0:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 1:
i1 = ((i0/i8)%i9);
 break;
case 2:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 3:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 4:
System.out.println("Hello");
 break;
default :
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

for(int i = 0; i < i5; i++){
 System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}

for(int i = 0; i < i9; i++){
 if( (((i4%i0)>i1)||(i1>=9))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
if( ((-4)<=(i1/i5))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
if( ((-6)<i5)){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
if( (i5>=(-2))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}
}
}
}
}

switch(i3){
case 0:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 1:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 2:
i7 = 8;
 break;
case 3:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
default :
System.out.println("Hello");
}

for(int i = 0; i < i6; i++){
 if( (i5!=i0)){
System.out.println("Hello");
System.out.println("Hello");
if( ((i3/i0)<(i3+i9))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
if( (5==i2)){
i0 = (3%9);

}
}
}
}

for(int i = 0; i < i3; i++){
 System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}
if( ((i9==6)&&(((((i4/i2)!=i4)||(i8>(i0%i0)))||((-4)==(i6-i2)))||((i6+i0)>=i1)))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}}


//Method
 public static void meth_2( int i0, int i1, int i2, int i3, int i4, int i5, int i6, int i7, int i8, int i9){
if( (((-5)<i1)&&(i8<=(i1*i7)))){
System.out.println("Hello");
System.out.println("Hello");
if( ((i7/i0)<i2)){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}
}if( (i7>=(-8))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
if( (i0>(-3))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
if( ((i6%i4)<=(i2*i8))){
i0 = ((i8*i5)%(i4%i6));
if( ((-5)==(i5+i6))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
if( (i1>=5)){
i6 = ((i6%i7)+(i4+i0));

}
}
}
}
}
switch(i1){
case 0:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 1:
System.out.println("Hello");
System.out.println("Hello");
 break;
case 2:
i1 = ((i8-i6)%(i3%i2));
 break;
case 3:
i5 = (i2+6);
 break;
default :
i5 = (i7+i1);
}

for(int i = 0; i < i9; i++){
 if( ((i9*i9)>i3)){
System.out.println("Hello");

}
}
if( (i0>(i9%i0))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
if( ((i7+i9)<i3)){
meth_1(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9);
if( ((-1)>=(i3+i0))){
i0 = ((i3*i3)-(i9%i8));

}
}
}
switch(i1){
case 0:
meth_1(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9);
 break;
case 1:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 2:
System.out.println("Hello");
System.out.println("Hello");
 break;
case 3:
meth_1(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9);
 break;
case 4:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
default :
i1 = ((i7%i6)/i0);
}
if( ((i5*i4)==i5)){
i8 = (9/(i1/i4));

}
for(int i = 0; i < i6; i++){
 System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}

if((i1==i6)){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}
else{
 System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

switch(i0){
case 0:
i9 = ((-8)/(i1-i2));
 break;
case 1:
i3 = ((-6)+i7);
 break;
case 2:
i9 = ((-1)%i7);
 break;
case 3:
i8 = (i8-i2);
 break;
default :
System.out.println("Hello");
}

if(((i1*i2)!=(i4/i2))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}
else{
 System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

if(((i4%i2)>i1)){
meth_1(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9);
}
else{
 System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

if((i6>=i7)){
meth_1(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9);
}
else{
 i6 = ((i4-i3)*i0);
}
}


//Method
 public static void meth_3( int i0, int i1, int i2, int i3, int i4, int i5, int i6, int i7, int i8, int i9){

for(int i = 0; i < i8; i++){
 if( (i1>=(i6%i0))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
if( ((i1*i6)<=(i4*i4))){
meth_2(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9);
if( ((i1*i5)<(i1+i2))){
i0 = (i8+(i2*i0));

}
}
}
}

for(int i = 0; i < i4; i++){
 if( ((i7<=(-8))||(i5>i7))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}
}

switch(i7){
case 0:
meth_1(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9);
 break;
case 1:
System.out.println("Hello");
 break;
case 2:
meth_2(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9);
 break;
case 3:
meth_2(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9);
 break;
default :
i7 = (9%(-4));
}

for(int i = 0; i < i6; i++){
 System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}
if( ((i5>=9)&&(i5<=(-1)))){
i8 = (i3%i6);

}if( (i2<=3)){
meth_1(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9);
if( (i3<=(i8/i2))){
meth_1(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9);
if( ((-2)<=(i3%i4))){
i4 = (i9*i6);

}
}
}if( ((-2)!=i2)){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
if( ((i5/i5)>(i3/i6))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
if( (i2>=6)){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
if( (i2<=i6)){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
if( (i6==(-2))){
System.out.println("Hello");
System.out.println("Hello");

}
}
}
}
}
switch(i7){
case 0:
meth_1(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9);
 break;
case 1:
i9 = (i5+(i5/i7));
 break;
case 2:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
default :
meth_1(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9);
}

switch(i0){
case 0:
meth_1(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9);
 break;
case 1:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
default :
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

switch(i2){
case 0:
System.out.println("Hello");
System.out.println("Hello");
 break;
case 1:
i6 = (i4*(i0-i5));
 break;
default :
i7 = ((-7)/(-3));
}

if((i3==(-5))){
i7 = ((i9+i3)%(-1));
}
else{
 System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

switch(i5){
case 0:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 1:
meth_2(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9);
 break;
case 2:
meth_2(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9);
 break;
default :
meth_1(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9);
}
}

}